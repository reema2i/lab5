from django.urls import path
from .views import add_book, book_list

urlpatterns = [
    path('', book_list, name='book_list'),
    path('add/', add_book, name='add_book'),
]
