from django.shortcuts import render



books = []
class Book:
    def __init__(self, book_title, author_name):
        self.book_title = book_title
        self.author_name = author_name

def add_book(request):
    if request.method == 'POST':
        book_title = request.POST.get('book_title')
        author_name = request.POST.get('author_name')
        thebook = Book(book_title, author_name)
        books.append(thebook)
    return render(request, 'add_book.html')

def book_list(request):
    return render(request, 'book_list.html', {'books': books})

# Create your views here.
